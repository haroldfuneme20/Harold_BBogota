package com.bancobogota.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.bancobogota.dao.EmployeeDAO;
import com.bancobogota.models.Employee;

@Service
public class EmployeeImplement implements IEmployee {
	
	@Autowired
	private EmployeeDAO employeeDao;

	@Override
	public List<Employee> findAll() {
		return employeeDao.findAll();
	}

	@Override
	public Page<Employee> findAll(Pageable pageable) {
		return employeeDao.findAll(pageable);
	}

	@Override
	public Employee findById(Integer id) {
		
		return employeeDao.findById(id).orElse(null);
	}

	@Override
	public Employee save(Employee employee) {
		return employeeDao.save(employee);
	}

	@Override
	public void deleteById(Integer id) {
		employeeDao.deleteById(id);
	}

}
