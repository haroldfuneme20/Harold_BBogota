package com.bancobogota.models;



import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;






@Entity
@Table(name="employee")
public class Employee  implements Serializable{
	

	private static final long serialVersionUID = 1L;

	@Id
	private Integer idemployee;

	private Integer idboss;
	
	@NotEmpty
	@Column
	private String fullname;
	
	@NotEmpty
	@Column
	private String functions;

	public int getIdemployee() {
		return idemployee;
	}

	public void setIdemployee(int idemployee) {
		this.idemployee = idemployee;
	}

	public int getIdboss() {
		return idboss;
	}

	public void setIdboss(int idboss) {
		this.idboss = idboss;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getFunctions() {
		return functions;
	}

	public void setFunctions(String functions) {
		this.functions = functions;
	}

	
	
	
	

}
